﻿namespace WebApplication3.Model
{
    public class StudentDetail
    {
        public int id { get; set; }
        public string StudentName { get; set; }
        public string City { get; set; }
        public int CourseId { get; set; }
    }
}
